# test_3 > 2024-09-30 4:52am
https://universe.roboflow.com/yolo-ccdgk/test_3-qm1g6

Provided by a Roboflow user
License: CC BY 4.0

